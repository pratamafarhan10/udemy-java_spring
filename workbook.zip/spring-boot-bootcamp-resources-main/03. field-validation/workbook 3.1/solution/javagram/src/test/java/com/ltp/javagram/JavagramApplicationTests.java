package com.ltp.javagram;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavagramApplicationTests {

	@Test
	void contextLoads() {
	}

}
