package com.ltp.utilitymethods;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UtilityMethodsApplication {

	public static void main(String[] args) {
		SpringApplication.run(UtilityMethodsApplication.class, args);
	}

}
