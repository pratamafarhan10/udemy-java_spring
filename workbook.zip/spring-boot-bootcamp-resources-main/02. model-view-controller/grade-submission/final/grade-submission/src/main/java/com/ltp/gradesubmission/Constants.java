package com.ltp.gradesubmission;

public class Constants {
    public static final int NOT_FOUND = -1000;
}
