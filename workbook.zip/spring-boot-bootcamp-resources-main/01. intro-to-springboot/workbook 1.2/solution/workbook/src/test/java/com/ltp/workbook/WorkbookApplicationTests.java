package com.ltp.workbook;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WorkbookApplicationTests {

	@Test
	void contextLoads() {
	}

}
